import { Component, OnInit } from '@angular/core';
import { CommonService } from '../_services/common.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registered-users',
  templateUrl: './registered-users.component.html',
  styleUrls: ['./registered-users.component.css']
})
export class RegisteredUsersComponent implements OnInit {

  users: any[];
  constructor(private common_service: CommonService, private _router: Router) { }

  ngOnInit() {
    this.getUsers();
  }

  getUsers() {
    this.common_service.getUsers().subscribe((res: any[]) => {
      console.log(res);
      this.users = res;
    });
  }

  editUser(userId: number) {
    console.log('Edit the user');
    this._router.navigate(['/edit', userId]);
  }
  deleteUser(userId: number) {
    this.common_service.deleteUser(userId)
      .subscribe( data => {
        this.users = this.users.filter(u => u !== userId);
        console.log('deleted user...!');
        this.getUsers();
      });
  }

}
