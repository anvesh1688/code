import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class CommonService {
    constructor(private http: HttpClient) { }
    baseUrl = 'http://localhost:3000/users';

    register(user: any) {
        return this.http.post(this.baseUrl, user);
    }
    getUsers() {
        return this.http.get(this.baseUrl);
    }
    getUser(id: number) {
        return this.http.get(this.baseUrl + '/' + id);
    }

    updateUser(user: any) {
        return this.http.put(this.baseUrl + '/' + user.id, user);
    }

    deleteUser(id: number) {
        return this.http.delete(this.baseUrl + '/' + id);
    }
}
