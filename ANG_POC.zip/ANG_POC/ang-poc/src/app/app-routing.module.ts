import { NoPageComponent } from './no-page/no-page.component';
import { AppComponent } from './app.component';
import { RegestrationComponent } from './regestration/regestration.component';
import { RegisteredUsersComponent } from './registered-users/registered-users.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'registration',
    pathMatch: 'full'
  },
  {
      path: 'registration',
      component: RegestrationComponent
  },
  { path: 'edit/:id', component: RegestrationComponent },
  {
    path: 'registered-users',
    component: RegisteredUsersComponent
  },
  {
    path: 'no-page',
    component: NoPageComponent
  },
  {path: '**', redirectTo: '/no-page'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
