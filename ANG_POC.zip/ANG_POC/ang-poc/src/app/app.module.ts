import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { RegisteredUsersComponent } from './registered-users/registered-users.component';
import { NoPageComponent } from './no-page/no-page.component';
import { RegestrationComponent } from './regestration/regestration.component';

import { HttpClientModule } from '@angular/common/http';
import { CommonService } from './_services/common.service';


@NgModule({
  declarations: [
    AppComponent,
    RegisteredUsersComponent,
    NoPageComponent,
    RegestrationComponent
  ],
  imports: [
    BrowserModule, AppRoutingModule, NgbModule, FormsModule, ReactiveFormsModule, HttpClientModule
  ],
  providers: [CommonService],
  bootstrap: [AppComponent]
})
export class AppModule { }
