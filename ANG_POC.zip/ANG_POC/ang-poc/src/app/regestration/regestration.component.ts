import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from '../_helpers/must-match.validator';
import { CommonService } from '../_services/common.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-regestration',
  templateUrl: './regestration.component.html',
  styleUrls: ['./regestration.component.css']
})
export class RegestrationComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  success_message = false;
  see_users_list = false;
  registered_users = 'No Users registered';
  show_message: any;
  constructor(private formBuilder: FormBuilder,
              private router: Router,
              private common_service: CommonService,
              private route: ActivatedRoute ) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
        firstName: ['', Validators.required],
        lastName: ['', Validators.required],
        userName: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        phoneNumber: ['', Validators.required],
        password: ['', [Validators.required, Validators.minLength(6)]],
        confirmPassword: ['', Validators.required]
    }, {
        validator: MustMatch('password', 'confirmPassword')
    });

    this.route.paramMap.subscribe(params => {
      const userId = +params.get('id');
      console.log(userId);
      if (userId) {
        this.getUser(userId);
      }
    });
  }

  get f() { return this.registerForm.controls; }
  onSubmit() {
      this.show_message = false;
      this.submitted = true;
      if (this.registerForm.valid) {
          this.success_message = true;
      }
      if (this.registerForm.invalid) {
          return;
      }
      alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value));
      this.common_service.register(this.registerForm.value).subscribe(
        data => {
            console.log(data);
            this.router.navigate(['/registered-users']);
        },
        error => {
            console.log('Error...!');
        });
  }

  regestredUsers() {
    if (this.submitted) {
      this.registered_users = 'You can see list of registered users';
      this.router.navigate(['registered-users']);
    }
  }

  getUser(id: number) {
    this.common_service.getUser(id)
      .subscribe(
        (user: any) => this.editUser(user),
        // (employee: any) => console.log(employee),
        (err: any) => console.log(err)
      );
  }

  editUser(user) {
    this.registerForm.patchValue({
      firstName: user.firstName,
      lastName: user.lastName,
      userName: user.userName,
      email: user.email,
      phoneNumber: user.phoneNumber,
      password: user.password,
      confirmPassword: user.confirmPassword,
    });
  }

}

